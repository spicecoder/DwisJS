define([
	"storehouse/test/storehouse"
], 1);
